<?php

function log_form()
{
}

function log_print()
{
  echo "\n";
  echo "  <log-handler name=\"\" level=\"all\" path=\"stdout:\">\n";
  echo "  <logger name=\"\" level=\"info\">\n";
}

?>